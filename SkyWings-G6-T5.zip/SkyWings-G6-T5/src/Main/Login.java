package Main;

import Admin.Admin_Page;
import Passenger.Sign_up;
import Passenger.Passenger_Page;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import Skywings.Passenger;
import java.util.Date;
import javax.swing.JFrame;


public class Login extends javax.swing.JFrame {


    public Login() {
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 750);  // Set the size of the frame
        setLocationRelativeTo(null);  // Center the frame on the screen
    }

     private boolean validateLogin(String email, String password) {
        boolean isValid = false;
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6");
           
  
            // SQL query to check if email and password match
            String sql = "SELECT * FROM Passenger WHERE P_Email = ? AND P_Password = ?";
            
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, email);
            pst.setString(2, password);
            
            
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                isValid = true;
            }
            
            rs.close();
            pst.close();
            con.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error connecting to the database: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace(); 
        }
        return isValid;
    }
     
     private boolean validateLogin2(String email2, String password2) {
        boolean isValid = false;
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6");
  
          
            String sql = "SELECT * FROM admin WHERE A_Email = ? AND A_Password = ?";
          
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, email2);
            pst.setString(2, password2);
            
            
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                isValid = true;
            }
            
            rs.close();
            pst.close();
            con.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error connecting to the database: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace(); 
        }
        return isValid;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Username = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        Pass = new javax.swing.JLabel();
        login = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        sign = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        icon = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Username.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Username.setText("Email");
        getContentPane().add(Username, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 290, 160, -1));

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 290, 340, 40));

        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 340, 340, 40));

        Pass.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Pass.setText("Password ");
        getContentPane().add(Pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 340, 161, -1));

        login.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        login.setText(" login ");
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });
        getContentPane().add(login, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 420, -1, -1));

        cancel.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        cancel.setText("Cancel");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });
        getContentPane().add(cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 420, -1, -1));

        sign.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        sign.setText("sign up");
        sign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signActionPerformed(evt);
            }
        });
        getContentPane().add(sign, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 550, -1, -1));

        jLabel1.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        jLabel1.setText("New user?   ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 560, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/profile.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, 200, 190));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/back.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1630, 750));

        jMenuBar1.setPreferredSize(new java.awt.Dimension(288, 72));

        icon.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Picture1.png"))); // NOI18N
        icon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        icon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        icon.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                iconAncestorMoved(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        icon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iconActionPerformed(evt);
            }
        });

        jMenuItem1.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem1.setText("About us");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem1);
        icon.add(jSeparator2);

        jMenuItem2.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem2.setText("Help   ");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem2);

        jMenuBar1.add(icon);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginActionPerformed
     String email = jTextField1.getText();
    String password = new String(jPasswordField1.getPassword());

    if (email.endsWith("@skywing.sa")) {
        // Admin login
        if (validateLogin2(email, password)) {
            // Redirect to admin page
            Admin_Page adminPage = new Admin_Page();
            adminPage.setVisible(true);
            this.dispose(); // Close the login window
        } else {
            JOptionPane.showMessageDialog(this, "Invalid admin credentials", "Login Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        // Passenger login
        if (validateLogin(email, password)) {
            Passenger loggedInPassenger = Passenger.fetchPassengerDetails(email, password);
            if (loggedInPassenger != null) {
                Passenger.login(loggedInPassenger); // Set the logged-in passenger
                Passenger_Page passengerPage = new Passenger_Page();
                passengerPage.setVisible(true);
                this.dispose(); 
            } else {
                JOptionPane.showMessageDialog(this, "Passenger details could not be loaded", "Login Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid passenger credentials", "Login Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    this.dispose();
    }//GEN-LAST:event_loginActionPerformed

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
        Home_page Cancel = new Home_page();
        Cancel.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_cancelActionPerformed

    private void signActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signActionPerformed
        Sign_up  new_user = new Sign_up();
        new_user.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_signActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        AboutUs us = new AboutUs();
        us.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        AboutHelp help = new AboutHelp();
        help.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void iconAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_iconAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_iconAncestorMoved

    private void iconActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iconActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iconActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Pass;
    private javax.swing.JLabel Username;
    private javax.swing.JButton cancel;
    private javax.swing.JMenu icon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton login;
    private javax.swing.JButton sign;
    // End of variables declaration//GEN-END:variables
}
