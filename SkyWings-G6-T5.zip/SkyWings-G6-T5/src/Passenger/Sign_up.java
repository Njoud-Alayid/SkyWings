

package Passenger; 

import Main.AboutHelp;
import Main.AboutUs;
import Main.Home_page;
import java.awt.BorderLayout;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.ResultSet;
import java.util.Scanner;


public class Sign_up extends javax.swing.JFrame {
  
    private final String note = "yyyy-MM-dd";
    private final String notep = "05xxxxxxxx";

    public Sign_up() {
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 750);  // Set the size of the frame
        setLocationRelativeTo(null);  // Center the frame on the screen
        
        jTextField5.setText(note); 
        jTextField5.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (jTextField5.getText().equals(note)) {
                    jTextField5.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (jTextField5.getText().isEmpty()) {
                    jTextField5.setText(note);
                }
            }
        });
        
        jTextField3.setText(notep); 
        jTextField3.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (jTextField3.getText().equals(notep)) {
                    jTextField3.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (jTextField3.getText().isEmpty()) {
                    jTextField3.setText(notep);
                }
            }
        } );
    
    
                }
  
    
    private void showTermsAndConditions() {
        try {
            File termsFile = new File("terms.txt");
            Scanner scanner = new Scanner(termsFile);

            StringBuilder termsText = new StringBuilder();
            while (scanner.hasNextLine()) {
                termsText.append(scanner.nextLine()).append("\n");
            }
            scanner.close();

            JTextArea termsArea = new JTextArea(termsText.toString());
            termsArea.setEditable(false);
            termsArea.setLineWrap(true);
            termsArea.setWrapStyleWord(true); 

            JScrollPane scrollPane = new JScrollPane(termsArea);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            JFrame termsFrame = new JFrame("Terms and Conditions");
            termsFrame.setLayout(new BorderLayout()); 

            
            termsArea.setRows(20); 
            termsArea.setColumns(50); 

            termsFrame.add(scrollPane, BorderLayout.CENTER); 
            termsFrame.setSize(600, 400); 
            termsFrame.setLocationRelativeTo(null);
            termsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            termsFrame.setVisible(true);

        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Terms and Conditions file not found!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        creat = new javax.swing.JButton();
        cancel_user = new javax.swing.JButton();
        jPasswordField2 = new javax.swing.JPasswordField();
        Pass1 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        Pass = new javax.swing.JLabel();
        Username2 = new javax.swing.JLabel();
        mail = new javax.swing.JCheckBox();
        femail = new javax.swing.JCheckBox();
        Lname = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        Fname = new javax.swing.JLabel();
        Phone = new javax.swing.JLabel();
        id = new javax.swing.JLabel();
        Email = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        terms = new javax.swing.JCheckBox();
        id1 = new javax.swing.JLabel();
        creat1 = new javax.swing.JButton();
        Username3 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        icon = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        jMenuItem2 = new javax.swing.JMenuItem();
        help = new javax.swing.JMenu();
        jMenu10 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        creat.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        creat.setText("Creat");
        creat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                creatActionPerformed(evt);
            }
        });
        getContentPane().add(creat, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 560, -1, -1));

        cancel_user.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        cancel_user.setText("Cancel");
        cancel_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancel_userActionPerformed(evt);
            }
        });
        getContentPane().add(cancel_user, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 560, -1, -1));

        jPasswordField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField2ActionPerformed(evt);
            }
        });
        getContentPane().add(jPasswordField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 410, 290, 40));

        Pass1.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Pass1.setText("Confirm password  ");
        getContentPane().add(Pass1, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 410, 310, 40));

        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 410, 290, 40));

        Pass.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Pass.setText("Password ");
        getContentPane().add(Pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 410, 150, -1));

        Username2.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Username2.setText("Gender ");
        getContentPane().add(Username2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 490, 120, -1));

        mail.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        mail.setText("Male");
        mail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mailActionPerformed(evt);
            }
        });
        getContentPane().add(mail, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 490, 120, -1));

        femail.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        femail.setText("Female");
        femail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                femailActionPerformed(evt);
            }
        });
        getContentPane().add(femail, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 490, 140, -1));

        Lname.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Lname.setText("Last name ");
        getContentPane().add(Lname, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 180, 180, -1));

        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 340, 290, 40));

        jLabel2.setFont(new java.awt.Font("Segoe Print", 1, 36)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Creat new account");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 30, 498, -1));

        Fname.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Fname.setText("First name ");
        getContentPane().add(Fname, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 180, 170, -1));

        Phone.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Phone.setText("Phone number");
        getContentPane().add(Phone, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 340, 300, -1));

        id.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        id.setForeground(new java.awt.Color(0, 153, 255));
        id.setText("terms and conditions");
        id.setToolTipText("Click here to view the terms");
        id.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                idMouseClicked(evt);
            }
        });
        getContentPane().add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 580, -1, -1));

        Email.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Email.setText("Email  ");
        getContentPane().add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 340, 100, -1));

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField2KeyTyped(evt);
            }
        });
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 260, 290, 40));

        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });
        jTextField7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField7KeyTyped(evt);
            }
        });
        getContentPane().add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 180, 290, 40));

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        jTextField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField6KeyTyped(evt);
            }
        });
        getContentPane().add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 180, 290, 40));

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        jTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField3KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField3KeyTyped(evt);
            }
        });
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 340, 290, 40));

        jTextField5.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        jTextField5.setToolTipText("");
        jTextField5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField5FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField5FocusLost(evt);
            }
        });
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 260, 290, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/profile_U.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 270, 190, 190));

        terms.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        terms.setText("I accpet the ");
        terms.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                termsMouseClicked(evt);
            }
        });
        terms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                termsActionPerformed(evt);
            }
        });
        getContentPane().add(terms, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 580, 210, -1));

        id1.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        id1.setText("National ID  ");
        getContentPane().add(id1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 260, -1, -1));

        creat1.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        creat1.setText("Clear");
        creat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                creat1ActionPerformed(evt);
            }
        });
        getContentPane().add(creat1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 560, -1, -1));

        Username3.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Username3.setText("Date of Birth");
        getContentPane().add(Username3, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 260, -1, 40));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/back.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1630, 860));

        jMenuBar1.setPreferredSize(new java.awt.Dimension(288, 72));

        icon.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Picture1.png"))); // NOI18N
        icon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        icon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        icon.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                iconAncestorMoved(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        icon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iconActionPerformed(evt);
            }
        });

        jMenuItem1.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem1.setText("About us");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem1);
        icon.add(jSeparator3);

        jMenuItem2.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem2.setText("Help   ");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem2);

        jMenuBar1.add(icon);

        help.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        help.setEnabled(false);
        help.setFont(new java.awt.Font("Urdu Typesetting", 0, 20)); // NOI18N
        help.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        help.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        help.setMinimumSize(new java.awt.Dimension(72, 22));
        help.setPreferredSize(new java.awt.Dimension(72, 22));
        help.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                helpComponentMoved(evt);
            }
            public void componentShown(java.awt.event.ComponentEvent evt) {
                helpComponentShown(evt);
            }
        });
        help.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpActionPerformed(evt);
            }
        });
        help.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                helpKeyPressed(evt);
            }
        });
        jMenuBar1.add(help);

        jMenu10.setEnabled(false);
        jMenu10.setMaximumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setMinimumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setPreferredSize(new java.awt.Dimension(1140, 32767));
        jMenuBar1.add(jMenu10);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void mailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mailActionPerformed
       if (mail.isSelected())
        {
            femail.setSelected(false);
        }
    }//GEN-LAST:event_mailActionPerformed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jPasswordField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField2ActionPerformed

    private void cancel_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancel_userActionPerformed
        Home_page Cancel = new Home_page();
        Cancel.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_cancel_userActionPerformed

    private void femailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_femailActionPerformed
             if (femail.isSelected())
        {
            mail.setSelected(false);
        }
    }//GEN-LAST:event_femailActionPerformed

    private void jTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField3KeyPressed
      
        // phone num 
        
        String phoneNumber = jTextField3.getText () ;

        int length = phoneNumber.length();

        char c = evt.getKeyChar () ;

        if (evt.getKeyChar ()>='0' && evt.getKeyChar () <='9') {

            if (length<10) {
                jTextField3.setEditable (true);
      }else{
                jTextField3.setEditable (false);
            }
            
        } else {
        
        if (evt.getExtendedKeyCode() == KeyEvent.VK_BACK_SPACE || evt.getExtendedKeyCode() == KeyEvent.VK_DELETE){
            
            jTextField3.setEditable (true);

              } else {
            
            jTextField3.setEditable (false);
        }
            
        }
        
    }//GEN-LAST:event_jTextField3KeyPressed

    private void jTextField3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField3KeyTyped

    }//GEN-LAST:event_jTextField3KeyTyped

    private void jTextField6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField6KeyTyped
         // first name 
        
        char n = evt.getKeyChar(); 
        if (!Character.isAlphabetic(n)){
           evt.consume();
        }
    }//GEN-LAST:event_jTextField6KeyTyped

    private void jTextField7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField7KeyTyped
             // last name
             
        char n = evt.getKeyChar(); 
        if (!Character.isAlphabetic(n)){
           evt.consume();
        }
    }//GEN-LAST:event_jTextField7KeyTyped

    private void jTextField2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField2KeyTyped
         // ID
        
        char n = evt.getKeyChar(); 
        if (!Character.isDigit(n)){
           evt.consume();
        }
    }//GEN-LAST:event_jTextField2KeyTyped

    private void termsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_termsActionPerformed
        
        
        
    }//GEN-LAST:event_termsActionPerformed

    private void termsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_termsMouseClicked
       
    }//GEN-LAST:event_termsMouseClicked

    private void idMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_idMouseClicked
       showTermsAndConditions();
    }//GEN-LAST:event_idMouseClicked

    private void creat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_creat1ActionPerformed
       
        jTextField6.setText("");
        jTextField7.setText("");
        jTextField2.setText("");
        jTextField5.setText(note);
        jTextField3.setText(notep);
        jTextField8.setText("");
        jPasswordField1.setText("");
        jPasswordField2.setText("");

        femail.setSelected(false);
        mail.setSelected(false);
        terms.setSelected(false);
          
    }//GEN-LAST:event_creat1ActionPerformed

    private void creatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_creatActionPerformed
        String firstName = jTextField6.getText();
        String lastName = jTextField7.getText();
        String nationalId = jTextField2.getText();
        String dobText = jTextField5.getText();
        String phoneNumber = jTextField3.getText();
        String email = jTextField8.getText();
        String password = new String(jPasswordField1.getPassword());
        String confirmPassword = new String(jPasswordField2.getPassword());
        String gender = mail.isSelected() ? "M" : "F";

        if (firstName.isEmpty() || lastName.isEmpty() || nationalId.isEmpty() || dobText.isEmpty() ||
            phoneNumber.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        if (!nationalId.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "National ID must be 10 numbers.");
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dob;
        try {
            dob = sdf.parse(dobText);
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use yyyy-MM-dd.");
            return;
        }

        if (dob.after(new Date(System.currentTimeMillis() - 18 * 31536000000L))) {
            JOptionPane.showMessageDialog(this, "You must be at least 18 years old to sign up.");
            return;
        }

        if (!phoneNumber.matches("05\\d{8}")) {
            JOptionPane.showMessageDialog(this, "Phone number must start with 05 and have 10 numbers.");
            return;
        }

        if (!email.matches("\\b[A-Za-z0-9._%+-]+@(gmail|hotmail)\\.com\\b")) {
            JOptionPane.showMessageDialog(this, "Invalid email format. Only emails ending with @gmail.com or @hotmail.com are allowed.");
            return;
        }

        if (!password.matches("^(?=.*[0-9])(?=.*[A-Z]).{8,15}$")) {
            JOptionPane.showMessageDialog(this, "Password must be 8-15 characters with at least one digit and one uppercase letter.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match.");
            return;
        }

        if (!terms.isSelected()) {
            JOptionPane.showMessageDialog(this, "Please agree to the terms and conditions.");
            return;
        }

        saveToDatabase(firstName, lastName, nationalId, dob, phoneNumber, email, password, gender);
        }

        private void saveToDatabase(String firstName, String lastName, String nationalId, Date dob,
            String phoneNumber, String email, String password, String gender) {

            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            // Connect to the database
            try {
                connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "Shadow$Njoud6");

                preparedStatement = connection.prepareStatement("SELECT P_SSN FROM skyWing.Passenger WHERE P_SSN = ?");
                preparedStatement.setString(1, nationalId);
                resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    JOptionPane.showMessageDialog(this, "National ID already exists.");
                    return;
                }

                preparedStatement = connection.prepareStatement("SELECT P_Phone FROM skyWing.Passenger WHERE P_Phone = ?");
                preparedStatement.setString(1, phoneNumber);
                resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    JOptionPane.showMessageDialog(this, "Phone number already exists.");
                    return;
                }

                preparedStatement = connection.prepareStatement("SELECT P_Email FROM skyWing.Passenger WHERE P_Email = ?");
                preparedStatement.setString(1, email);
                resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    JOptionPane.showMessageDialog(this, "Email already exists.");
                    return;
                }

                preparedStatement = connection.prepareStatement(
                    "INSERT INTO skyWing.Passenger (P_FName, P_LName, P_SSN, P_Bdate, P_Phone, P_Email, P_Password, P_Gender) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

                preparedStatement.setString(1, firstName);
                preparedStatement.setString(2, lastName);
                preparedStatement.setString(3, nationalId);
                preparedStatement.setDate(4, new java.sql.Date(dob.getTime()));
                preparedStatement.setString(5, phoneNumber);
                preparedStatement.setString(6, email);
                preparedStatement.setString(7, password);
                preparedStatement.setString(8, gender);

                preparedStatement.executeUpdate();

                JOptionPane.showMessageDialog(this, "Account created successfully!");
                Passenger_Page s = new Passenger_Page();
                s.setVisible(true);
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error occurred while saving to database: " + e.getMessage());
            } finally {

                try {
                    if (resultSet != null) resultSet.close();
                    if (preparedStatement != null) preparedStatement.close();
                    if (connection != null) connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            
            this.dispose();

    }//GEN-LAST:event_creatActionPerformed

    private void jTextField5FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField5FocusLost

                
            
    }//GEN-LAST:event_jTextField5FocusLost

    private void jTextField5FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField5FocusGained
   
 
             
    }//GEN-LAST:event_jTextField5FocusGained

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        AboutUs us = new AboutUs();
        us.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        AboutHelp help = new AboutHelp();
        help.setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void iconAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_iconAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_iconAncestorMoved

    private void iconActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iconActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iconActionPerformed

    private void helpComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentMoved

    private void helpComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentShown

    private void helpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpActionPerformed

    private void helpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_helpKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Sign_up.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Sign_up.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Sign_up.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Sign_up.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sign_up().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Email;
    private javax.swing.JLabel Fname;
    private javax.swing.JLabel Lname;
    private javax.swing.JLabel Pass;
    private javax.swing.JLabel Pass1;
    private javax.swing.JLabel Phone;
    private javax.swing.JLabel Username2;
    private javax.swing.JLabel Username3;
    private javax.swing.JButton cancel_user;
    private javax.swing.JButton creat;
    private javax.swing.JButton creat1;
    private javax.swing.JCheckBox femail;
    private javax.swing.JMenu help;
    private javax.swing.JMenu icon;
    private javax.swing.JLabel id;
    private javax.swing.JLabel id1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JCheckBox mail;
    private javax.swing.JCheckBox terms;
    // End of variables declaration//GEN-END:variables
}




