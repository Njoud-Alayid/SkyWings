package Passenger; 
import Main.AboutUs;
import Main.AboutHelp;
import Main.Home_page;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Passenger_book extends javax.swing.JFrame {

    public Passenger_book() {
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 750);  // Set the size of the frame
        setLocationRelativeTo(null);  // Center the frame on the screen
        
        
        DefaultTableModel model = new DefaultTableModel(new String[]{"FlightNo", "FlightType", "DepartTime", "ArrivalTime", "DepartCity", "ArrivalCity", "DepartAirport", "ArrivalAirport", "AirplaneID", "Gate", "F_Date"}, 0);
        jTable1.setModel(model);
          try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM skyWing.Flight");

            while (resultSet.next()) {
                model.addRow(new Object[]{
                        resultSet.getString("FlightNo"),
                        resultSet.getString("FlightType"),
                        resultSet.getTime("DepartTime"),
                        resultSet.getTime("ArrivalTime"),
                        resultSet.getString("DepartCity"),
                        resultSet.getString("ArrivalCity"),
                        resultSet.getString("DepartAirport"),
                        resultSet.getString("ArrivalAirport"),
                        resultSet.getString("AirplaneID"),
                        resultSet.getString("Gate"),
                        resultSet.getDate("F_Date")
                });
            }

            jTable1.setModel(model);

            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
            jTable1.setDefaultEditor(Object.class, null);
    }

Passenger_seatF frame = new Passenger_seatF();

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane5 = new javax.swing.JScrollPane();
        jList5 = new javax.swing.JList<>();
        jFileChooser1 = new javax.swing.JFileChooser();
        jLabel9 = new javax.swing.JLabel();
        RoundButton = new javax.swing.JButton();
        OneButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        SubmitButton = new javax.swing.JButton();
        BackButton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        icon = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        jMenuItem2 = new javax.swing.JMenuItem();
        help = new javax.swing.JMenu();
        jMenu10 = new javax.swing.JMenu();
        prof = new javax.swing.JMenu();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItem3 = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        Logout = new javax.swing.JMenuItem();

        jList5.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane5.setViewportView(jList5);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Segoe Print", 1, 36)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Booking your plane ");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 40, 498, -1));

        RoundButton.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        RoundButton.setText("Round");
        RoundButton.setMaximumSize(new java.awt.Dimension(152, 45));
        RoundButton.setMinimumSize(new java.awt.Dimension(152, 45));
        RoundButton.setPreferredSize(new java.awt.Dimension(152, 45));
        RoundButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RoundButtonActionPerformed(evt);
            }
        });
        getContentPane().add(RoundButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 170, -1, 50));

        OneButton.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        OneButton.setText("One-Way");
        OneButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OneButtonActionPerformed(evt);
            }
        });
        getContentPane().add(OneButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 170, -1, 50));

        jTable1.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "FlightNo ", "FlightType", "DepartTime", "ArrivalTime", "DepartCity", "ArrivalCity", "DepartAirport", "ArrivalAirport", "AirplanID", "Gate", "F_Date"
            }
        ));
        jTable1.setRowHeight(30);
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 250, 1130, 220));

        SubmitButton.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        SubmitButton.setText("Submit");
        SubmitButton.setMaximumSize(new java.awt.Dimension(152, 45));
        SubmitButton.setMinimumSize(new java.awt.Dimension(152, 45));
        SubmitButton.setPreferredSize(new java.awt.Dimension(152, 45));
        SubmitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubmitButtonActionPerformed(evt);
            }
        });
        getContentPane().add(SubmitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 570, -1, -1));

        BackButton.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        BackButton.setText("Back");
        BackButton.setMaximumSize(new java.awt.Dimension(152, 45));
        BackButton.setMinimumSize(new java.awt.Dimension(152, 45));
        BackButton.setPreferredSize(new java.awt.Dimension(152, 45));
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });
        getContentPane().add(BackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 570, -1, -1));

        jLabel6.setFont(new java.awt.Font("Sitka Heading", 1, 30)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Choose your Flight Type:");
        jLabel6.setToolTipText("");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 370, -1));

        jLabel7.setFont(new java.awt.Font("Sitka Heading", 0, 30)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Select your plane");
        jLabel7.setToolTipText("");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 510, 240, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/book_back.png"))); // NOI18N
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1630, 760));

        jMenuBar1.setPreferredSize(new java.awt.Dimension(288, 72));

        icon.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Picture1.png"))); // NOI18N
        icon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        icon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        icon.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                iconAncestorMoved(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        icon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iconActionPerformed(evt);
            }
        });

        jMenuItem1.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem1.setText("About us");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem1);
        icon.add(jSeparator3);

        jMenuItem2.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem2.setText("Help   ");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem2);

        jMenuBar1.add(icon);

        help.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        help.setEnabled(false);
        help.setFont(new java.awt.Font("Urdu Typesetting", 0, 20)); // NOI18N
        help.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        help.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        help.setMinimumSize(new java.awt.Dimension(72, 22));
        help.setPreferredSize(new java.awt.Dimension(72, 22));
        help.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                helpComponentMoved(evt);
            }
            public void componentShown(java.awt.event.ComponentEvent evt) {
                helpComponentShown(evt);
            }
        });
        help.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpActionPerformed(evt);
            }
        });
        help.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                helpKeyPressed(evt);
            }
        });
        jMenuBar1.add(help);

        jMenu10.setEnabled(false);
        jMenu10.setMaximumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setMinimumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setPreferredSize(new java.awt.Dimension(1140, 32767));
        jMenuBar1.add(jMenu10);

        prof.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/profile_user.png"))); // NOI18N
        prof.add(jSeparator1);

        jMenuItem3.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem3.setText("Home");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        prof.add(jMenuItem3);
        prof.add(jSeparator2);

        Logout.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        Logout.setText("Logout");
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });
        prof.add(Logout);

        jMenuBar1.add(prof);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void RoundButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RoundButtonActionPerformed
DefaultTableModel model = new DefaultTableModel(new String[]{"FlightNo", "FlightType", "DepartTime", "ArrivalTime", "DepartCity", "ArrivalCity", "DepartAirport", "ArrivalAirport", "AirplaneID", "Gate", "F_Date"}, 0);
        jTable1.setModel(model);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6"); Statement stmt = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY); ResultSet rs = stmt.executeQuery("SELECT * FROM skyWing.Flight WHERE FlightType LIKE 'round%'")) {

            while (rs.next()) {
                model.addRow(new Object[]{rs.getString("FlightNo"), rs.getString("FlightType"), rs.getString("DepartTime"), rs.getString("ArrivalTime"), rs.getString("DepartCity"), rs.getString("ArrivalCity"), rs.getString("DepartAirport"), rs.getString("ArrivalAirport"), rs.getString("AirplaneID"), rs.getString("Gate"), rs.getString("F_Date")});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error in fetching data: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_RoundButtonActionPerformed

    private void OneButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OneButtonActionPerformed
        DefaultTableModel model = new DefaultTableModel(new String[]{"FlightNo", "FlightType", "DepartTime", "ArrivalTime", "DepartCity", "ArrivalCity", "DepartAirport", "ArrivalAirport", "AirplaneID", "Gate", "F_Date"}, 0);
        jTable1.setModel(model);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6"); Statement stmt = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY); ResultSet rs = stmt.executeQuery("SELECT * FROM skyWing.Flight WHERE FlightType LIKE 'one%'")) {

            while (rs.next()) {
                model.addRow(new Object[]{rs.getString("FlightNo"), rs.getString("FlightType"), rs.getString("DepartTime"), rs.getString("ArrivalTime"), rs.getString("DepartCity"), rs.getString("ArrivalCity"), rs.getString("DepartAirport"), rs.getString("ArrivalAirport"), rs.getString("AirplaneID"), rs.getString("Gate"), rs.getString("F_Date")});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error in fetching data: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_OneButtonActionPerformed

    private void SubmitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubmitButtonActionPerformed
  int row = jTable1.getSelectedRow();

    if (row != -1) {
        String flightNo = jTable1.getValueAt(row, 0).toString();
    
        frame.prepareForBooking(flightNo);  
        frame.setVisible(true);
    } else {
        JOptionPane.showMessageDialog(null, "No row selected!");
    }
    
    this.dispose();
   
    }//GEN-LAST:event_SubmitButtonActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed

        Passenger_availableF Available = new Passenger_availableF();
        Available.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_BackButtonActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        AboutUs us = new AboutUs();
        us.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        AboutHelp help = new AboutHelp();
        help.setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void iconAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_iconAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_iconAncestorMoved

    private void iconActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iconActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iconActionPerformed

    private void helpComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentMoved

    private void helpComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentShown

    private void helpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpActionPerformed

    private void helpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_helpKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpKeyPressed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        Passenger_Page home = new Passenger_Page();
        home.setVisible(true);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        Home_page logout = new Home_page();
        logout.setVisible(true);
    }//GEN-LAST:event_LogoutActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Passenger_book.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Passenger_book.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Passenger_book.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Passenger_book.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Passenger_book().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackButton;
    private javax.swing.JMenuItem Logout;
    private javax.swing.JButton OneButton;
    private javax.swing.JButton RoundButton;
    private javax.swing.JButton SubmitButton;
    private javax.swing.JMenu help;
    private javax.swing.JMenu icon;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList<String> jList5;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JTable jTable1;
    private javax.swing.JMenu prof;
    // End of variables declaration//GEN-END:variables
}
