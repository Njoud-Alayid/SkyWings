package Passenger;
import Main.AboutUs;
import Main.AboutHelp;
import Main.Home_page;

import javax.swing.*;
import Skywings.Passenger;
import Skywings.Passenger;
import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Passenger_bookInfo extends javax.swing.JFrame {

    private String flightNo;
    private String selectedSeat;
    private String totalPrice;
    private DefaultListModel<String> seatModel;
    private Passenger loggedInPassenger;
   

    public Passenger_bookInfo() {
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 750);  // Set the size of the frame
        setLocationRelativeTo(null);  // Center the frame on the screen
        fetchPassengerName();
        
        // Loop through all JTextFields
        for (Component component : getContentPane().getComponents()) {
            if (component instanceof JTextField) {
                JTextField textField = (JTextField) component;
                textField.setEditable(false); 
            }
        }

    }

        public void setFlightNo(String flightNo) {
        this.flightNo = flightNo;
        fetchFlightDetails();
         txtFlightNo.setText(flightNo);
          txtFlightNo2.setText(flightNo);
    }
    public void getFlightNo(String flightNo) {
        this.flightNo = flightNo;

    }
public void setSeatNo(String seat) {
    this.selectedSeat = seat;
    jTextField8.setText(seat); 
}


    public void getSeatNo(String seat) {
        this.selectedSeat = seat;
    }

public void setTotalPrice(String price) {
    this.totalPrice = price;
    jTextField9.setText(price); 
}
    public void getTotalPrice(String seatPrice) {
        this.totalPrice =seatPrice; 
        jTextField9.setText(seatPrice);
    }


    private void fetchFlightDetails() {
    if (flightNo == null || flightNo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Flight number is not specified.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6");
         PreparedStatement pst = con.prepareStatement("SELECT DepartTime, DepartAirport, ArrivalAirport, Gate, F_Date FROM skywing.Flight WHERE FlightNo = ?")) {

        pst.setString(1, flightNo);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            txtDepartTime.setText(rs.getString("DepartTime"));
            txtDepartAirport.setText(rs.getString("DepartAirport"));
            txtArrivalAirport.setText(rs.getString("ArrivalAirport"));
            txtGate.setText(rs.getString("Gate"));
            txtDate.setText(rs.getString("F_Date"));
                        txtDepartTime2.setText(rs.getString("DepartTime"));
            txtDepartAirport2.setText(rs.getString("DepartAirport"));
            txtArrivalAirport2.setText(rs.getString("ArrivalAirport"));
            txtGate2.setText(rs.getString("Gate"));
        } else {
            JOptionPane.showMessageDialog(this, "No flight details found for flight number: " + flightNo, "No Data", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error fetching flight details: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}

   

private void fetchPassengerName() {
    Passenger passenger = Passenger.getLoggedInPassenger();
    if (passenger != null) {
        String fullName = passenger.getFName() + " " + passenger.getLName(); 
        jTextField1.setText(fullName); 
        jTextField11.setText(fullName); 
    } else {
        jTextField1.setText("Not logged in"); 
        jTextField11.setText("Not logged in");
    }
}


    private void bordingInfo() {
        String ssn = Passenger.getLoggedInPassenger().getSSN();
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6")) {
            String sql = "SELECT  DepartTime, DepartAirport, ArrivalAirport, Gate, F_Date FROM skywing.Flight  WHERE FlightNo = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, ssn);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                txtDepartTime2.setText(rs.getString("DepartTime"));
                txtDepartAirport2.setText(rs.getString("DepartAirport"));
                txtArrivalAirport2.setText(rs.getString("ArrivalAirport"));
                txtGate2.setText(rs.getString("Gate"));
            }
            rs.close();
            pst.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching flight details: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Back2book2 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        txtDepartTime = new javax.swing.JTextField();
        txtGate = new javax.swing.JTextField();
        txtFlightNo = new javax.swing.JTextField();
        txtDate = new javax.swing.JTextField();
        txtDepartAirport = new javax.swing.JTextField();
        txtArrivalAirport = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        txtDepartTime2 = new javax.swing.JTextField();
        txtGate2 = new javax.swing.JTextField();
        txtFlightNo2 = new javax.swing.JTextField();
        txtDepartAirport2 = new javax.swing.JTextField();
        txtArrivalAirport2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        confirmButton = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        icon = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        jMenuItem2 = new javax.swing.JMenuItem();
        help = new javax.swing.JMenu();
        jMenu10 = new javax.swing.JMenu();
        prof = new javax.swing.JMenu();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItem3 = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        Logout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Back2book2.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Back2book2.setText("Back");
        Back2book2.setPreferredSize(new java.awt.Dimension(140, 45));
        Back2book2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Back2book2Back2bookActionPerformed(evt);
            }
        });
        getContentPane().add(Back2book2, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 620, 160, 50));

        jLabel9.setFont(new java.awt.Font("Segoe Print", 1, 36)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Your booking information");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 60, 498, -1));

        jTextField1.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 200, 260, -1));

        txtDepartTime.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtDepartTime.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(txtDepartTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 280, 110, -1));

        txtGate.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtGate.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(txtGate, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 280, 60, -1));

        txtFlightNo.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtFlightNo.setForeground(new java.awt.Color(0, 50, 147));
        txtFlightNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFlightNoActionPerformed(evt);
            }
        });
        getContentPane().add(txtFlightNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 280, 60, -1));

        txtDate.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtDate.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(txtDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 350, 90, -1));

        txtDepartAirport.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtDepartAirport.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(txtDepartAirport, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 350, 90, -1));

        txtArrivalAirport.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtArrivalAirport.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(txtArrivalAirport, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 430, 80, -1));

        jTextField8.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        jTextField8.setForeground(new java.awt.Color(0, 50, 147));
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 510, 70, -1));

        jTextField9.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        jTextField9.setForeground(new java.awt.Color(0, 50, 147));
        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 510, 90, -1));

        jTextField11.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        jTextField11.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(jTextField11, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 320, 260, -1));

        txtDepartTime2.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtDepartTime2.setForeground(new java.awt.Color(0, 50, 147));
        txtDepartTime2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDepartTime2ActionPerformed(evt);
            }
        });
        getContentPane().add(txtDepartTime2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 400, 110, -1));

        txtGate2.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtGate2.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(txtGate2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 400, 60, -1));

        txtFlightNo2.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtFlightNo2.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(txtFlightNo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 400, 60, -1));

        txtDepartAirport2.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtDepartAirport2.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(txtDepartAirport2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 490, 80, -1));

        txtArrivalAirport2.setFont(new java.awt.Font("Sitka Subheading", 0, 18)); // NOI18N
        txtArrivalAirport2.setForeground(new java.awt.Color(0, 50, 147));
        getContentPane().add(txtArrivalAirport2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 490, 80, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Ticket.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, -1, -1));

        confirmButton.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        confirmButton.setText("confirm");
        confirmButton.setMaximumSize(new java.awt.Dimension(93, 45));
        confirmButton.setMinimumSize(new java.awt.Dimension(93, 45));
        confirmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmButtonActionPerformed(evt);
            }
        });
        getContentPane().add(confirmButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 620, 160, 50));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/book_back.png"))); // NOI18N
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1630, 760));

        jMenuBar1.setPreferredSize(new java.awt.Dimension(288, 72));

        icon.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Picture1.png"))); // NOI18N
        icon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        icon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        icon.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                iconAncestorMoved(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        icon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iconActionPerformed(evt);
            }
        });

        jMenuItem1.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem1.setText("About us");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem1);
        icon.add(jSeparator3);

        jMenuItem2.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem2.setText("Help   ");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem2);

        jMenuBar1.add(icon);

        help.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        help.setEnabled(false);
        help.setFont(new java.awt.Font("Urdu Typesetting", 0, 20)); // NOI18N
        help.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        help.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        help.setMinimumSize(new java.awt.Dimension(72, 22));
        help.setPreferredSize(new java.awt.Dimension(72, 22));
        help.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                helpComponentMoved(evt);
            }
            public void componentShown(java.awt.event.ComponentEvent evt) {
                helpComponentShown(evt);
            }
        });
        help.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpActionPerformed(evt);
            }
        });
        help.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                helpKeyPressed(evt);
            }
        });
        jMenuBar1.add(help);

        jMenu10.setEnabled(false);
        jMenu10.setMaximumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setMinimumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setPreferredSize(new java.awt.Dimension(1140, 32767));
        jMenuBar1.add(jMenu10);

        prof.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/profile_user.png"))); // NOI18N
        prof.add(jSeparator1);

        jMenuItem3.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem3.setText("Home");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        prof.add(jMenuItem3);
        prof.add(jSeparator2);

        Logout.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        Logout.setText("Logout");
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });
        prof.add(Logout);

        jMenuBar1.add(prof);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Back2book2Back2bookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Back2book2Back2bookActionPerformed
        Passenger_seatF back = new Passenger_seatF();
        back.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_Back2book2Back2bookActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void txtFlightNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFlightNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFlightNoActionPerformed

    private void confirmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmButtonActionPerformed
    String passengerSSN = Passenger.getLoggedInPassenger().getSSN();
    String flightNo = txtFlightNo.getText();
    String totalPrice = "1530";  // Static price as per your request
    String reservationCode = generateReservationCode();  // Generate a reservation code

    if (flightNo.isEmpty() || selectedSeat.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill all fields before confirming.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6")) {
        String sql = "INSERT INTO Reservation (ReservationCode, Passneger_SSN, FlightNo, SeatNo, TotalPrice) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, reservationCode);
        pst.setString(2, passengerSSN);
        pst.setString(3, flightNo);
        pst.setString(4, selectedSeat);
        pst.setString(5, totalPrice);

        int affectedRows = pst.executeUpdate();
        if (affectedRows > 0) {
            JOptionPane.showMessageDialog(this, "Booking confirmed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
             Payment paymentScreen = new Payment();
            paymentScreen.setVisible(true);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(this, "Booking confirmation failed.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    }
    
    this.dispose();
} 
    

private String generateReservationCode() {
    return Long.toString(System.currentTimeMillis()).substring(3, 9); 
    
    }//GEN-LAST:event_confirmButtonActionPerformed

    private void txtDepartTime2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDepartTime2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDepartTime2ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        AboutUs us = new AboutUs();
        us.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        AboutHelp help = new AboutHelp();
        help.setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void iconAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_iconAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_iconAncestorMoved

    private void iconActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iconActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iconActionPerformed

    private void helpComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentMoved

    private void helpComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentShown

    private void helpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpActionPerformed

    private void helpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_helpKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpKeyPressed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        Passenger_Page home = new Passenger_Page();
        home.setVisible(true);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        Home_page logout = new Home_page();
        logout.setVisible(true);
    }//GEN-LAST:event_LogoutActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Passenger_bookInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Passenger_bookInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Passenger_bookInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Passenger_bookInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Passenger_bookInfo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back2book2;
    private javax.swing.JMenuItem Logout;
    private javax.swing.JButton confirmButton;
    private javax.swing.JMenu help;
    private javax.swing.JMenu icon;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JMenu prof;
    private javax.swing.JTextField txtArrivalAirport;
    private javax.swing.JTextField txtArrivalAirport2;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtDepartAirport;
    private javax.swing.JTextField txtDepartAirport2;
    private javax.swing.JTextField txtDepartTime;
    private javax.swing.JTextField txtDepartTime2;
    private javax.swing.JTextField txtFlightNo;
    private javax.swing.JTextField txtFlightNo2;
    private javax.swing.JTextField txtGate;
    private javax.swing.JTextField txtGate2;
    // End of variables declaration//GEN-END:variables
}
