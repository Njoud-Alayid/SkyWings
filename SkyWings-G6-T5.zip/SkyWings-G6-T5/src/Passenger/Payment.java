package Passenger;
import Main.AboutUs;
import Main.AboutHelp;
import Main.Home_page;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.DocumentFilter.FilterBypass;





public class Payment extends javax.swing.JFrame {

    public Payment() {
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 750);  // Set the size of the frame
        setLocationRelativeTo(null);  // Center the frame on the screen
        addCustomListeners();
    }

    public static void main(String args[]) {
        EventQueue.invokeLater(() -> new Payment().setVisible(true));
    }

    private void addCustomListeners() {
        FocusAdapter clearTextAdapter = new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                JTextField source = (JTextField) e.getSource();
                if (source == cardNum && source.getText().trim().equals("XXXX-XXXX-XXXX-XXXX")) {
                    source.setText("");
                } else if (source == cardCVV && source.getText().trim().equals("XXX")) {
                    source.setText("");
                }
            }
        };

        cardNum.addFocusListener(clearTextAdapter);
        cardCVV.addFocusListener(clearTextAdapter);
        cardName.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                JTextField source = (JTextField) e.getSource();
                source.setText(""); // Clear the name field when it gains focus
            }
        });

        cardNum.setDocument(new PlainDocument() {
            @Override
            public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
                if (str == null) return;
                String currentText = getText(0, getLength());
                String beforeOffset = currentText.substring(0, offs);
                String afterOffset = currentText.substring(offs);
                String newStr = beforeOffset + str.replaceAll("[^\\d]", "") + afterOffset;
                newStr = newStr.replaceAll("[^\\d]", "");

                if (newStr.length() > 16) {
                    newStr = newStr.substring(0, 16); // Cut off excess digits
                }

                StringBuilder formattedStr = new StringBuilder();
                for (int i = 0; i < newStr.length(); i++) {
                    if (i > 0 && i % 4 == 0) {
                        formattedStr.append("-");
                    }
                    formattedStr.append(newStr.charAt(i));
                }

                super.remove(0, getLength());
                super.insertString(0, formattedStr.toString(), a);
            }
        });

        cardCVV.setDocument(new PlainDocument() {
            @Override
            public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
                if (str == null) return;
                String currentText = getText(0, getLength());
                String beforeOffset = currentText.substring(0, offs);
                String afterOffset = currentText.substring(offs);
                String newStr = beforeOffset + str.replaceAll("[^\\d]", "") + afterOffset;
                newStr = newStr.replaceAll("[^\\d]", "");

                if (newStr.length() > 3) {
                    newStr = newStr.substring(0, 3);
                }

                super.remove(0, getLength());
                super.insertString(0, newStr, a);
            }
        });

        ((PlainDocument) cardName.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text.matches("[^0-9]")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }

   private void processPayment() {
        if (validateCard()) {
            JOptionPane.showMessageDialog(this, "Booking succeeded! An email with flight details has been sent.", "Success", JOptionPane.INFORMATION_MESSAGE);
            this.dispose(); 
            new Passenger_viewF().setVisible(true); 
    
        }
   }

    private boolean validateCard() {
        if (!cardNum.getText().matches("\\d{4}-\\d{4}-\\d{4}-\\d{4}")) {
            JOptionPane.showMessageDialog(this, "Invalid card number format. Please enter in the format XXXX-XXXX-XXXX-XXXX.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (!cardCVV.getText().matches("\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Invalid CVV. Please enter a 3-digit CVV.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (!isValidExpiryDate()) {
            JOptionPane.showMessageDialog(this, "Card has expired.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private boolean isValidExpiryDate() {
        try {
            String expiryDateStr = month.getSelectedItem() + "/01/" + year.getSelectedItem();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate expiryDate = LocalDate.parse(expiryDateStr, formatter);
            return !expiryDate.isBefore(LocalDate.now());
        } catch (DateTimeParseException e) {
            return false;
        }
    }


    

   private void addCardNumberFormatting() {
        cardNum.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c) && c != KeyEvent.VK_BACK_SPACE) {
                    e.consume();  
                } else {
                    String text = cardNum.getText();
                    if (text.length() == 19) {  
                        e.consume();
                    } else if ((text.replace("-", "").length() + 1) % 5 == 0 && text.length() < 19) {
                        cardNum.setText(text + "-");
                    }
                }
            }
        });
    }
   
     private void addFocusListeners() {
        FocusListener clearTextListener = new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                JTextField source = (JTextField) e.getSource();
                String text = source.getText();
                if (text.equals("Enter card number") || text.equals("XXXX-XXXX-XXXX-XXXX") || 
                    text.equals("Enter CVV") || text.equals("XXX") || 
                    text.equals("Enter card holder's name") || text.equals("Name")) {
                    source.setText("");
                }
            }
            public void focusLost(FocusEvent e) {
                JTextField source = (JTextField) e.getSource();
                if (source.getText().isEmpty()) {
                    if (source == cardNum) source.setText("Enter card number");
                    else if (source == cardCVV) source.setText("Enter CVV");
                    else if (source == cardName) source.setText("Enter card holder's name");
                }
            }
        };

        cardNum.addFocusListener(clearTextListener);
        cardCVV.addFocusListener(clearTextListener);
        cardName.addFocusListener(clearTextListener);
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel12 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cardCVV = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cardNum = new javax.swing.JTextField();
        cardName = new javax.swing.JTextField();
        month = new java.awt.Choice();
        year = new java.awt.Choice();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        icon = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        jMenuItem2 = new javax.swing.JMenuItem();
        help = new javax.swing.JMenu();
        jMenu10 = new javax.swing.JMenu();
        prof = new javax.swing.JMenu();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItem3 = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        Logout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Segoe Print", 1, 36)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("Your Card information");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 60, 498, -1));

        jLabel6.setFont(new java.awt.Font("Sitka Heading", 0, 30)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Expiration Date");
        jLabel6.setToolTipText("");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 320, 210, -1));

        cardCVV.setFont(new java.awt.Font("Segoe UI", 0, 26)); // NOI18N
        cardCVV.setText("XXX");
        cardCVV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardCVVActionPerformed(evt);
            }
        });
        getContentPane().add(cardCVV, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 390, 110, 50));

        jLabel7.setFont(new java.awt.Font("Sitka Heading", 0, 30)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Card number");
        jLabel7.setToolTipText("");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 218, 180, 30));

        jLabel8.setFont(new java.awt.Font("Sitka Heading", 0, 30)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Card holder name");
        jLabel8.setToolTipText("");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 428, 240, 30));

        cardNum.setFont(new java.awt.Font("Segoe UI", 0, 26)); // NOI18N
        cardNum.setText("XXXX-XXXX-XXXX-XXXX");
        addCardNumberFormatting();
        cardNum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cardNumKeyTyped(evt);
            }
        });
        getContentPane().add(cardNum, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 250, 350, -1));

        cardName.setFont(new java.awt.Font("Segoe UI", 0, 26)); // NOI18N
        cardName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardNameActionPerformed(evt);
            }
        });
        getContentPane().add(cardName, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 460, 520, -1));

        for (int i = 1; i <= 12; i++) {
            month.add(String.format("%02d", i));  // Add months as "01", "02", ..., "12"
        }
        month.setFont(new java.awt.Font("Dialog", 0, 26)); // NOI18N
        getContentPane().add(month, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 360, 110, -1));

        int currentYear = LocalDate.now().getYear();
        for (int i = currentYear; i <= currentYear + 20; i++) {
            year.add(Integer.toString(i));  // Populate years
        }
        year.setFont(new java.awt.Font("Dialog", 0, 26)); // NOI18N
        getContentPane().add(year, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 360, 110, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Payment.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 150, -1, -1));

        jButton1.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        jButton1.setText("CANCEL");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 610, -1, -1));

        jButton2.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        jButton2.setText("PAY");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 610, 140, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/paymentBack.png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, -10, -1, 900));

        jMenuBar1.setPreferredSize(new java.awt.Dimension(288, 72));

        icon.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Picture1.png"))); // NOI18N
        icon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        icon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        icon.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                iconAncestorMoved(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        icon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iconActionPerformed(evt);
            }
        });

        jMenuItem1.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem1.setText("About us");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem1);
        icon.add(jSeparator3);

        jMenuItem2.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem2.setText("Help   ");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem2);

        jMenuBar1.add(icon);

        help.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        help.setEnabled(false);
        help.setFont(new java.awt.Font("Urdu Typesetting", 0, 20)); // NOI18N
        help.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        help.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        help.setMinimumSize(new java.awt.Dimension(72, 22));
        help.setPreferredSize(new java.awt.Dimension(72, 22));
        help.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                helpComponentMoved(evt);
            }
            public void componentShown(java.awt.event.ComponentEvent evt) {
                helpComponentShown(evt);
            }
        });
        help.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpActionPerformed(evt);
            }
        });
        help.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                helpKeyPressed(evt);
            }
        });
        jMenuBar1.add(help);

        jMenu10.setEnabled(false);
        jMenu10.setMaximumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setMinimumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setPreferredSize(new java.awt.Dimension(1140, 32767));
        jMenuBar1.add(jMenu10);

        prof.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/profile_user.png"))); // NOI18N
        prof.add(jSeparator1);

        jMenuItem3.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem3.setText("Home");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        prof.add(jMenuItem3);
        prof.add(jSeparator2);

        Logout.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        Logout.setText("Logout");
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });
        prof.add(Logout);

        jMenuBar1.add(prof);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void cardNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cardNameActionPerformed

    private void cardCVVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardCVVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cardCVVActionPerformed

    private void cardNumKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cardNumKeyTyped
addCardNumberFormatting();

    }//GEN-LAST:event_cardNumKeyTyped

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        AboutUs us = new AboutUs();
        us.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        AboutHelp help = new AboutHelp();
        help.setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void iconAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_iconAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_iconAncestorMoved

    private void iconActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iconActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iconActionPerformed

    private void helpComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentMoved

    private void helpComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentShown

    private void helpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpActionPerformed

    private void helpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_helpKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpKeyPressed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        Passenger_Page home = new Passenger_Page();
        home.setVisible(true);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        Home_page logout = new Home_page();
        logout.setVisible(true);
    }//GEN-LAST:event_LogoutActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int result = JOptionPane.showConfirmDialog(this, "Are you sure you want to cancel?", "Confirm Cancellation", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            this.dispose();
            new Passenger_book().setVisible(true);
        }
        
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (validateCard()) {
            JOptionPane.showMessageDialog(this, "Booking succeeded! An email with flight details has been sent.", "Success", JOptionPane.INFORMATION_MESSAGE);
            this.dispose();
            new Passenger_viewF().setVisible(true);
        }

    }//GEN-LAST:event_jButton2ActionPerformed


    
    
    
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Logout;
    private javax.swing.JTextField cardCVV;
    private javax.swing.JTextField cardName;
    private javax.swing.JTextField cardNum;
    private javax.swing.JMenu help;
    private javax.swing.JMenu icon;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private java.awt.Choice month;
    private javax.swing.JMenu prof;
    private java.awt.Choice year;
    // End of variables declaration//GEN-END:variables
}
