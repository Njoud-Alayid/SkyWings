package Passenger;
import Main.AboutUs;
import Main.AboutHelp;

import Skywings.Passenger;
import Main.Home_page;
import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;


public class Passenger_seatF extends javax.swing.JFrame {
    private DefaultListModel<String> seatModel = new DefaultListModel<>();
    private String flightNo;
    private boolean isUpdateMode;  
      private boolean isBookingMode = false; 

    public Passenger_seatF() {
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 750);  // Set the size of the frame
        setLocationRelativeTo(null);  // Center the frame on the screen
        
        this.isUpdateMode = false;  
        fetchAvailableSeats(flightNo);  
        jList3.setModel(seatModel);
        jList3.addListSelectionListener(e -> {
    if (!e.getValueIsAdjusting()) {  //  check so  event is processed only once per selection change
        updateTotalPrice();
    }
});

jList2.addListSelectionListener(e -> {
    if (!e.getValueIsAdjusting()) {
        updateTotalPrice();
    }
});
    }



    public void prepareForBooking(String flightNo) {
        this.flightNo = flightNo;
        this.isBookingMode = true; 
        fetchAvailableSeats(this.flightNo);
    }

    public void prepareForSeatUpdate(String flightNo) {
        this.flightNo = flightNo;
        this.isBookingMode = false; 
        fetchAvailableSeats(this.flightNo);
    }

    private void fetchAvailableSeats(String flightNo) {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6")){
            PreparedStatement pst = con.prepareStatement("SELECT SeatNo FROM skywing.Reservation WHERE FlightNo = ?");
            pst.setString(1, flightNo);
            ResultSet rs = pst.executeQuery();
            List<String> reservedSeats = new ArrayList<>();
            while (rs.next()) {
                reservedSeats.add(rs.getString("SeatNo"));
            }
            seatModel.clear();
            String[] allSeats = {"A1", "A2", "A3", "A4", "A5", "A6", "A7", "B1", "B2", "B3", "B4", "B5", "B6", "B7",
                                 "C1", "C2", "C3", "C4", "C5", "C6", "C7", "D1", "D2", "D3", "D4", "D5", "D6", "D7"};
            for (String seat : allSeats) {
                if (!reservedSeats.contains(seat)) {
                    seatModel.addElement(seat);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error fetching seats: " + ex.getMessage());
        }
    }

 private void updateSeat(String newSeat) {
    if(isBookingMode == false ){
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6")) {
            String updateQuery = "UPDATE skywing.Reservation SET SeatNo = ? WHERE FlightNo = ? AND Passneger_SSN = ?";
            PreparedStatement pst = con.prepareStatement(updateQuery);
            pst.setString(1, newSeat);
            pst.setString(2, flightNo);
            pst.setString(3, Passenger.getLoggedInPassenger().getSSN());  
            int affectedRows = pst.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(null, "Seat updated successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Seat update failed. No changes were made.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error updating seat: " + ex.getMessage());
        }
    }
 }

private void updateTotalPrice() {
    if (!jList3.isSelectionEmpty() && !jList2.isSelectionEmpty()) {
        String selectedSeat = jList3.getSelectedValue();
        String selectedMeal = jList2.getSelectedValue();

        int seatPrice = 1500; 
        int mealPrice;
        try {
            mealPrice = extractPriceFromMeal(selectedMeal);
        } catch (NumberFormatException ex) {
            mealPrice = 0; 
        }

        int totalPrice = seatPrice + mealPrice;
        jTextField1.setText(totalPrice + " SR"); 
    }
}


private int extractPriceFromMeal(String meal) {
    try {
        String pricePart = meal.substring(meal.lastIndexOf("(") + 1, meal.lastIndexOf(" SR)"));
        return Integer.parseInt(pricePart);
    } catch (Exception e) {
        return 0; 
    }
}


private void bookSeat(String seat) {
    Connection con = null;
    isBookingMode = false; 
    PreparedStatement pst = null;
    if(isBookingMode = false ){
    try {
       con = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6");
        String sql = "INSERT INTO skywing.Reservation (FlightNo, Passneger_SSN, SeatNo) VALUES (?, ?, ?)";
        pst = con.prepareStatement(sql);
        pst.setString(1, flightNo);
        pst.setString(2, Passenger.getLoggedInPassenger().getSSN());  
        pst.setString(3, seat);

        int affectedRows = pst.executeUpdate();
        if (affectedRows > 0) {
            JOptionPane.showMessageDialog(null, "Seat booked successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Failed to book the seat.");
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error booking seat: " + ex.getMessage());
    } finally {
        try {
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error closing connection: " + ex.getMessage());
        }
    }
}
}

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cancel_user = new javax.swing.JButton();
        Confirm = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jList3 = new javax.swing.JList<>();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList2 = new javax.swing.JList<>();
        jLabel12 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        icon = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        jMenuItem2 = new javax.swing.JMenuItem();
        help = new javax.swing.JMenu();
        jMenu10 = new javax.swing.JMenu();
        prof = new javax.swing.JMenu();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItem3 = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        Logout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cancel_user.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        cancel_user.setText("Cancel");
        cancel_user.setPreferredSize(new java.awt.Dimension(140, 45));
        cancel_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancel_userActionPerformed(evt);
            }
        });
        getContentPane().add(cancel_user, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 610, -1, -1));

        Confirm.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Confirm.setText("Confirm");
        Confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmActionPerformed(evt);
            }
        });
        getContentPane().add(Confirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 610, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe Print", 1, 36)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Choose your seat and meal");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 30, 498, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/NumSeat.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 0, -1, 723));

        jLabel5.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        jLabel5.setText("Total Price (SR)");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 500, 230, 50));

        jList3.setFont(new java.awt.Font("Sitka Subheading", 0, 24)); // NOI18N
        jList3.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "A1", "A2", "A3", "A4", "A5", "A6", "A7", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "C1", "C2", "C3", "C4", "C5", "C6", "C7", "D1", "D2", "D3", "D4", "D5", "D6", "D7" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(jList3);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 210, 170, 210));

        jLabel7.setFont(new java.awt.Font("Sitka Subheading", 1, 30)); // NOI18N
        jLabel7.setText("Available seat");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 158, -1, 50));

        jTextField1.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 500, 280, -1));

        jLabel10.setFont(new java.awt.Font("Sitka Subheading", 1, 30)); // NOI18N
        jLabel10.setText("Meal");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 160, 85, 50));

        jList2.setFont(new java.awt.Font("Sitka Subheading", 0, 24)); // NOI18N
        jList2.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Omelette with vegetables (30 SR)", "Pancakes with maple syrup (30 SR)", "Croissants (30 SR)", "Cheese (30 SR)", "Fruit (30 SR)", "Cereal with milk (30 SR)", "Breakfast burrito (30 SR)", "Grilled chicken with rice and vegetables (30 SR)", "Beef stew with mashed potatoes (30 SR)", "Pasta with marinara sauce (30 SR)", "Vegetarian curry with rice (30 SR)", "Fish with couscous (30 SR)", "Stir-fried tofu with noodles (30 SR)" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(jList2);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 200, 550, 210));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/book_back.png"))); // NOI18N
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1630, 760));

        jMenuBar1.setPreferredSize(new java.awt.Dimension(288, 72));

        icon.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Picture1.png"))); // NOI18N
        icon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        icon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        icon.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                iconAncestorMoved(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        icon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iconActionPerformed(evt);
            }
        });

        jMenuItem1.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem1.setText("About us");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem1);
        icon.add(jSeparator3);

        jMenuItem2.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem2.setText("Help   ");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem2);

        jMenuBar1.add(icon);

        help.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        help.setEnabled(false);
        help.setFont(new java.awt.Font("Urdu Typesetting", 0, 20)); // NOI18N
        help.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        help.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        help.setMinimumSize(new java.awt.Dimension(72, 22));
        help.setPreferredSize(new java.awt.Dimension(72, 22));
        help.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                helpComponentMoved(evt);
            }
            public void componentShown(java.awt.event.ComponentEvent evt) {
                helpComponentShown(evt);
            }
        });
        help.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpActionPerformed(evt);
            }
        });
        help.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                helpKeyPressed(evt);
            }
        });
        jMenuBar1.add(help);

        jMenu10.setEnabled(false);
        jMenu10.setMaximumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setMinimumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setPreferredSize(new java.awt.Dimension(1140, 32767));
        jMenuBar1.add(jMenu10);

        prof.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/profile_user.png"))); // NOI18N
        prof.add(jSeparator1);

        jMenuItem3.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem3.setText("Home");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        prof.add(jMenuItem3);
        prof.add(jSeparator2);

        Logout.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        Logout.setText("Logout");
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });
        prof.add(Logout);

        jMenuBar1.add(prof);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cancel_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancel_userActionPerformed
        Passenger_book back = new Passenger_book();
        back.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_cancel_userActionPerformed

    private void ConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmActionPerformed
    if (!jList3.isSelectionEmpty()) {
        String selectedSeat = jList3.getSelectedValue();
        updateTotalPrice(); 
        String totalPrice = jTextField1.getText();

        if (isBookingMode) {
            bookSeat(selectedSeat);
            Passenger_bookInfo bookinfo = new Passenger_bookInfo();
      bookinfo.setFlightNo(flightNo);
            bookinfo.setSeatNo(selectedSeat);
            bookinfo.setTotalPrice(totalPrice);
            bookinfo.setVisible(true);
        } else {
            updateSeat(selectedSeat);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a seat before confirming.");
    }
    
    this.dispose();
    }//GEN-LAST:event_ConfirmActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
    updateTotalPrice();
    
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        AboutUs us = new AboutUs();
        us.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        AboutHelp help = new AboutHelp();
        help.setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void iconAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_iconAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_iconAncestorMoved

    private void iconActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iconActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iconActionPerformed

    private void helpComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentMoved

    private void helpComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentShown

    private void helpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpActionPerformed

    private void helpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_helpKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpKeyPressed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        Passenger_Page home = new Passenger_Page();
        home.setVisible(true);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        Home_page logout = new Home_page();
        logout.setVisible(true);
    }//GEN-LAST:event_LogoutActionPerformed

    
    public static void main(String args[]) {
     
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Passenger_seatF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Passenger_seatF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Passenger_seatF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Passenger_seatF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Passenger_seatF().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Confirm;
    private javax.swing.JMenuItem Logout;
    private javax.swing.JButton cancel_user;
    private javax.swing.JMenu help;
    private javax.swing.JMenu icon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList<String> jList2;
    private javax.swing.JList<String> jList3;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JMenu prof;
    // End of variables declaration//GEN-END:variables
}
