
package Skywings;

public class Reservation {
    
    
    //attributes
    private String ReservationCode; //6 diigit
    private String FlightNo; //3 char
    private String SeatNo; //2 chat
    private String Passneger_SSN; //10 digit
    private int TotalPrice; //calculated by a method
    
    
    //constructor
    public Reservation(String ReservationCode, String FlightNo, String SeatNo, String Passneger_SSN, int TotalPrice) {
        this.ReservationCode = ReservationCode;
        this.FlightNo = FlightNo;
        this.SeatNo = SeatNo;
        this.Passneger_SSN = Passneger_SSN;
        this.TotalPrice = TotalPrice;
    }
    
    
    
    //setters & getters
    public String getReservationCode() {
        return ReservationCode;
    }

    public void setReservationCode(String ReservationCode) {
        this.ReservationCode = ReservationCode;
    }

    public String getFlightNo() {
        return FlightNo;
    }

    public void setFlightNo(String FlightNo) {
        this.FlightNo = FlightNo;
    }

    public String getSeatNo() {
        return SeatNo;
    }

    public void setSeatNo(String SeatNo) {
        this.SeatNo = SeatNo;
    }

    public String getPassneger_SSN() {
        return Passneger_SSN;
    }

    public void setPassneger_SSN(String Passneger_SSN) {
        this.Passneger_SSN = Passneger_SSN;
    }

    public int getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(int TotalPrice) {
        this.TotalPrice = TotalPrice;
    }
    
    
}
