

package Skywings;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.JOptionPane;

public class Passenger extends User {

    private static Passenger loggedInPassenger;

    public Passenger(String SSN, String FName, String LName, Date Bdate, char Gender, String Email, String Password, String Phone) {
        super(SSN, FName, LName, Bdate, Gender, Email, Password, Phone);
    }

    public static void login(Passenger passenger) {
        loggedInPassenger = passenger;
    }

    public static Passenger getLoggedInPassenger() {
        return loggedInPassenger;
    }

    public static void logout() {
        loggedInPassenger = null;
    }
    
public static Passenger fetchPassengerDetails(String email, String password) {
    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6")) {
        String sql = "SELECT * FROM Passenger WHERE P_Email = ? AND P_Password = ?";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, email);
        pst.setString(2, password);
        ResultSet rs = pst.executeQuery();
        
        if (rs.next()) {
            String ssn = rs.getString("P_SSN");
            String fName = rs.getString("P_FName");
            String lName = rs.getString("P_LName");
            Date bDate = rs.getDate("P_Bdate");
            char gender = rs.getString("P_Gender").charAt(0);
            String phone = rs.getString("P_Phone");
            return new Passenger(ssn, fName, lName, bDate, gender, email, password, phone);
        }
        rs.close();
        pst.close();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Database connection error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    }
    return null;
}

}
