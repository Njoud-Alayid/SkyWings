
package Skywings;

public class Airport {
    
    //attributes
    private String AirportID;
    private String AirportName;
    private String Location;
    
    //constructor
    public Airport(String AirportID, String AirportName, String Location) {
        this.AirportID = AirportID;
        this.AirportName = AirportName;
        this.Location = Location;
    }
    
    //setters & getters
    public String getAirportID() {
        return AirportID;
    }

    public void setAirportID(String AirportID) {
        this.AirportID = AirportID;
    }

    public String getAirportName() {
        return AirportName;
    }

    public void setAirportName(String AirportName) {
        this.AirportName = AirportName;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }
    
    
    
}
