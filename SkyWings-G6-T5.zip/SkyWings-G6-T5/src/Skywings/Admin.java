
package Skywings;

import Skywings.User;
import java.util.Date;

public class Admin extends User {
    
    //attributes
    private String AdminID; //10 digit
    private double Salary;
    
    //constructor
    public Admin(String AdminID, double Salary, String SSN, String FName, String LName, Date Bdate, char Gender, String Email, String Password, String Phone) {
        super(SSN, FName, LName, Bdate, Gender, Email, Password, Phone);
        this.AdminID = AdminID;
        this.Salary = Salary;
    }
    
    
    
    //setters & getters
    public String getAdminID() {
        return AdminID;
    }

    public void setAdminID(String AdminID) {
        this.AdminID = AdminID;
    }

    public double getSalary() {
        return Salary;
    }

    public void setSalary(double Salary) {
        this.Salary = Salary;
    }

    
    //methods
    public void viewFlight() {}
    
    public void addFlight() {}
    
    public void updateFlight() {}
    
    public void deleteFlight() {}
    
   
}
