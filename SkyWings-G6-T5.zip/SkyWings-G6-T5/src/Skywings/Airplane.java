
package Skywings;

public class Airplane {
    
    //attributes
    private String AirplaneID;
    private int Capacity;
    
    
    //constructor
    public Airplane(String AirplaneID, int Capacity) {
        this.AirplaneID = AirplaneID;
        this.Capacity = Capacity;
    }
    
    
    //setters & getters
    public String getAirplaneID() {
        return AirplaneID;
    }

    public void setAirplaneID(String AirplaneID) {
        this.AirplaneID = AirplaneID;
    }

    public int getCapacity() {
        return Capacity;
    }

    public void setCapacity(int Capacity) {
        this.Capacity = Capacity;
    }
    
    
    
    
}
