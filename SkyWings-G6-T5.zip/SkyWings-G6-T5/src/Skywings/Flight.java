
package Skywings;

import java.util.Date;

public class Flight {
    
    //attributes
    private String FlightNo; //3 char
    private String FlightType; //OR enum? //checkbox
    private String DepartTime; //time?
    private String ArrivalTime; //time?
    private String DepartCity; //OR enum?
    private String ArrivalCity; //OR enum?
    private String DepartAirport; //OR enum? //3 char
    private String ArrivalAirport; //OR enum? //3 char
    private String AirplaneID; //5 char
    private String Gate; //2 char
    private Date F_Date;
    
    
    //constructor
    public Flight(String FlightNo, String FlightType, String DepartTime, String ArrivalTime, String DepartCity, String ArrivalCity, String DepartAirport, String ArrivalAirport, String AirplaneID, String Gate, Date F_Date) {
        this.FlightNo = FlightNo;
        this.FlightType = FlightType;
        this.DepartTime = DepartTime;
        this.ArrivalTime = ArrivalTime;
        this.DepartCity = DepartCity;
        this.ArrivalCity = ArrivalCity;
        this.DepartAirport = DepartAirport;
        this.ArrivalAirport = ArrivalAirport;
        this.AirplaneID = AirplaneID;
        this.Gate = Gate;
        this.F_Date = F_Date;
    }
    
    //setters & getters
    public String getFlightNo() {
        return FlightNo;
    }

    public void setFlightNo(String FlightNo) {
        this.FlightNo = FlightNo;
    }

    public String getFlightType() {
        return FlightType;
    }

    public void setFlightType(String FlightType) {
        this.FlightType = FlightType;
    }

    public String getDepartTime() {
        return DepartTime;
    }

    public void setDepartTime(String DepartTime) {
        this.DepartTime = DepartTime;
    }

    public String getArrivalTime() {
        return ArrivalTime;
    }

    public void setArrivalTime(String ArrivalTime) {
        this.ArrivalTime = ArrivalTime;
    }

    public String getDepartCity() {
        return DepartCity;
    }

    public void setDepartCity(String DepartCity) {
        this.DepartCity = DepartCity;
    }

    public String getArrivalCity() {
        return ArrivalCity;
    }

    public void setArrivalCity(String ArrivalCity) {
        this.ArrivalCity = ArrivalCity;
    }

    public String getDepartAirport() {
        return DepartAirport;
    }

    public void setDepartAirport(String DepartAirport) {
        this.DepartAirport = DepartAirport;
    }

    public String getArrivalAirport() {
        return ArrivalAirport;
    }

    public void setArrivalAirport(String ArrivalAirport) {
        this.ArrivalAirport = ArrivalAirport;
    }

    public String getAirplaneID() {
        return AirplaneID;
    }

    public void setAirplaneID(String AirplaneID) {
        this.AirplaneID = AirplaneID;
    }

    public String getGate() {
        return Gate;
    }

    public void setGate(String Gate) {
        this.Gate = Gate;
    }

    public Date getF_Date() {
        return F_Date;
    }

    public void setF_Date(Date F_Date) {
        this.F_Date = F_Date;
    }
    
    
    
}
