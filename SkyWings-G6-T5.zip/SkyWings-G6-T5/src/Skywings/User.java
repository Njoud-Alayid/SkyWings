
package Skywings;

import java.util.Date;

public class User {
    
    //attributes   
    private String SSN; //10 digit
    private String FName; //20 char
    private String LName; //20 char
    Date Bdate;
    private char Gender; //1 char F/M
    private String Email; //100 char
    private String Password; // 8- 15 char
    private String Phone; //10 digit
    
    
    //constructor
    public User(String SSN, String FName, String LName, Date Bdate, char Gender, String Email, String Password, String Phone) {
        this.SSN = SSN;
        this.FName = FName;
        this.LName = LName;
        this.Bdate = Bdate;
        this.Gender = Gender;
        this.Email = Email;
        this.Password = Password;
        this.Phone = Phone;
    }

    //setters & getters
    public String getSSN() {
        return SSN;
    }

    public void setSSN(String SSN) {
        this.SSN = SSN;
    }

    public String getFName() {
        return FName;
    }

    public void setFName(String FName) {
        this.FName = FName;
    }

    public String getLName() {
        return LName;
    }

    public void setLName(String LName) {
        this.LName = LName;
    }

    public Date getBdate() {
        return Bdate;
    }

    public void setBdate(Date Bdate) {
        this.Bdate = Bdate;
    }

    public char getGender() {
        return Gender;
    }

    public void setGender(char Gender) {
        this.Gender = Gender;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }
    
    
    
}
