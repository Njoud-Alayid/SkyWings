/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author f
 */

package Admin;
        
import Passenger.Passenger_Page;
import Main.AboutHelp;
import Main.AboutUs;
import Main.Home_page;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import java.sql.Timestamp;
import java.sql.Time ;
import javax.swing.JFrame;



public class Admin_addF extends javax.swing.JFrame {

 
    
    public Admin_addF() {

        initComponents();{
        
    // اضافه حق الوقت 
    
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            Date midnight = calendar.getTime();

            departTimeSpinner.setModel(new SpinnerDateModel(midnight, null, null, Calendar.HOUR_OF_DAY));
            JSpinner.DateEditor departTimeEditor = new JSpinner.DateEditor(departTimeSpinner, "HH:mm:ss");
            departTimeSpinner.setEditor(departTimeEditor);


            arrivalTimeSpinner.setModel(new SpinnerDateModel(midnight, null, null, Calendar.HOUR_OF_DAY));
            JSpinner.DateEditor arrivalTimeEditor = new JSpinner.DateEditor(arrivalTimeSpinner, "HH:mm:ss");
            arrivalTimeSpinner.setEditor(arrivalTimeEditor);


            dateSpinner.setModel(new SpinnerDateModel());
            JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
            dateSpinner.setEditor(dateEditor);
    }
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 750);  // Set the size of the frame
        setLocationRelativeTo(null);  // Center the frame on the screen   
        
// اضافه شادن ------------------------------ + عدلت على ال اانترفيس حذفت حق المطارات 

        departCityComboBox.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            updateArrivalCityComboBox();
        }
    });
    updateArrivalCityComboBox(); 
 // اضافه شادن ------------------------------
 
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fname = new javax.swing.JLabel();
        id = new javax.swing.JLabel();
        Email = new javax.swing.JLabel();
        Username = new javax.swing.JLabel();
        Add = new javax.swing.JButton();
        Email2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Fname1 = new javax.swing.JLabel();
        Email7 = new javax.swing.JLabel();
        Email8 = new javax.swing.JLabel();
        Email9 = new javax.swing.JLabel();
        arrivalCityComboBox = new javax.swing.JComboBox<>();
        flightTypeComboBox = new javax.swing.JComboBox<>();
        departCityComboBox = new javax.swing.JComboBox<>();
        airplaneIdComboBox = new javax.swing.JComboBox();
        gateComboBox = new javax.swing.JComboBox<>();
        departTimeSpinner = new javax.swing.JSpinner();
        dateSpinner = new javax.swing.JSpinner();
        arrivalTimeSpinner = new javax.swing.JSpinner();
        Email3 = new javax.swing.JLabel();
        flightNoTextField = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        icon = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        help = new javax.swing.JMenu();
        jMenu10 = new javax.swing.JMenu();
        prof = new javax.swing.JMenu();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItem3 = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        Logout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fname.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Fname.setText("Flight number");
        getContentPane().add(Fname, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, 220, -1));

        id.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        id.setText("Depart Time");
        getContentPane().add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 220, 180, -1));

        Email.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        getContentPane().add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 410, -1, -1));

        Username.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Username.setText("Arrival Time");
        getContentPane().add(Username, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 280, 180, -1));

        Add.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Add.setText("Add Flight");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        getContentPane().add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 600, -1, -1));

        Email2.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Email2.setText("Arrival City");
        getContentPane().add(Email2, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 390, 170, -1));

        jLabel9.setFont(new java.awt.Font("Segoe Print", 1, 36)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Add new flight");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 50, 490, -1));

        Fname1.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Fname1.setText("Flight type");
        getContentPane().add(Fname1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 300, 160, -1));

        Email7.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Email7.setText("Gate");
        getContentPane().add(Email7, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 160, 70, -1));

        Email8.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Email8.setText("Airplane ID");
        getContentPane().add(Email8, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 230, 170, 40));

        Email9.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Email9.setText("Flight Date");
        getContentPane().add(Email9, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 340, 160, -1));

        arrivalCityComboBox.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        arrivalCityComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dammam", "Jeddah", "Riyadh" }));
        arrivalCityComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                arrivalCityComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(arrivalCityComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 390, 210, -1));

        flightTypeComboBox.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        flightTypeComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "round", "oneway" }));
        flightTypeComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flightTypeComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(flightTypeComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 300, -1, -1));

        departCityComboBox.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        departCityComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dammam", "Jeddah", "Riyadh" }));
        departCityComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                departCityComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(departCityComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 360, -1, -1));

        airplaneIdComboBox.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        airplaneIdComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "SWA#1", "SWA#2", "SWA#3", "SWA#4", "SWA#5", "SWA#6" }));
        airplaneIdComboBox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                airplaneIdComboBoxMouseClicked(evt);
            }
        });
        getContentPane().add(airplaneIdComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 230, -1, -1));

        gateComboBox.setFont(new java.awt.Font("Sitka Subheading", 1, 24)); // NOI18N
        gateComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07" }));
        getContentPane().add(gateComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 160, -1, -1));

        departTimeSpinner.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        departTimeSpinner.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                departTimeSpinnerMouseClicked(evt);
            }
        });
        getContentPane().add(departTimeSpinner, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 220, 210, -1));

        dateSpinner.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        dateSpinner.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                dateSpinnerAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(dateSpinner, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 340, 210, -1));

        arrivalTimeSpinner.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        arrivalTimeSpinner.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                arrivalTimeSpinnerAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(arrivalTimeSpinner, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 280, 210, -1));

        Email3.setFont(new java.awt.Font("Sitka Subheading", 0, 30)); // NOI18N
        Email3.setText("Departure City");
        getContentPane().add(Email3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 360, 220, -1));

        flightNoTextField.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        flightNoTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flightNoTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(flightNoTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 160, 290, 40));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Adminback.png"))); // NOI18N
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -190, 1630, 1020));

        jMenuBar1.setPreferredSize(new java.awt.Dimension(288, 72));

        icon.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Picture1.png"))); // NOI18N
        icon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        icon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        icon.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                iconAncestorMoved(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        icon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iconActionPerformed(evt);
            }
        });

        jMenuItem1.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem1.setText("About us");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem1);

        jMenuItem2.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem2.setText("Help   ");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        icon.add(jMenuItem2);

        jMenuBar1.add(icon);

        help.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        help.setEnabled(false);
        help.setFont(new java.awt.Font("Urdu Typesetting", 0, 20)); // NOI18N
        help.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        help.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        help.setMinimumSize(new java.awt.Dimension(72, 22));
        help.setPreferredSize(new java.awt.Dimension(72, 22));
        help.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                helpComponentMoved(evt);
            }
            public void componentShown(java.awt.event.ComponentEvent evt) {
                helpComponentShown(evt);
            }
        });
        help.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpActionPerformed(evt);
            }
        });
        help.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                helpKeyPressed(evt);
            }
        });
        jMenuBar1.add(help);

        jMenu10.setEnabled(false);
        jMenu10.setMaximumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setMinimumSize(new java.awt.Dimension(1140, 32767));
        jMenu10.setPreferredSize(new java.awt.Dimension(1140, 32767));
        jMenuBar1.add(jMenu10);

        prof.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/profile_admin.png"))); // NOI18N
        prof.add(jSeparator1);

        jMenuItem3.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        jMenuItem3.setText("Home");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        prof.add(jMenuItem3);
        prof.add(jSeparator2);

        Logout.setFont(new java.awt.Font("Urdu Typesetting", 1, 16)); // NOI18N
        Logout.setText("Logout");
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });
        prof.add(Logout);

        jMenuBar1.add(prof);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        // Get input values
 
        String flightNo = flightNoTextField.getText();
        String flightType = (String) flightTypeComboBox.getSelectedItem();
        String departCity = (String) departCityComboBox.getSelectedItem();
        String arrivalCity = (String) arrivalCityComboBox.getSelectedItem();
        String airplaneId = (String) airplaneIdComboBox.getSelectedItem();
        String gate = (String) gateComboBox.getSelectedItem();

      
        Date departDate = (Date) departTimeSpinner.getValue();
        Date arrivalDate = (Date) arrivalTimeSpinner.getValue();
        Date flightDate = (Date) dateSpinner.getValue();

        if (flightNo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill the fields.");
            return;
        }


        if (flightNo.length() != 3 || !flightNo.matches("\\d{3}")) {
                    JOptionPane.showMessageDialog(this, "Flight number must be exactly three digits!");
                    return; }

        saveFlightToDatabase(flightNo, flightType, departDate, arrivalDate, departCity, arrivalCity, airplaneId, gate, flightDate);
        
        Admin_Page F = new Admin_Page();
        F.setVisible(true); 
        
        this.dispose();
    }
    
    
 // اضافه شادن ------------------------------  
    
    
    private void updateArrivalCityComboBox() {
    
    arrivalCityComboBox.removeAllItems();
    
    String selectedDepartureCity = (String) departCityComboBox.getSelectedItem();
    
    for (String city : new String[]{"Dammam", "Jeddah", "Riyadh"}) {
        if (!city.equals(selectedDepartureCity)) {
            arrivalCityComboBox.addItem(city);
        }
    }
}

// اضافه شادن ------------------------------
    
    
    private void saveFlightToDatabase(String flightNo, String flightType, Date departDate, Date arrivalDate, String departCity, String arrivalCity,
        String airplaneId, String gate, Date flightDate) {
        
        Time departTime = new Time(departDate.getTime());
        Time arrivalTime = new Time(arrivalDate.getTime());


            Connection connection = null;
            PreparedStatement preparedStatement1 = null;
            ResultSet resultSet = null;

    
            try {
             connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/skyWing", "root", "Shadow$Njoud6");
  
                preparedStatement1 = connection.prepareStatement("SELECT FlightNo FROM skyWing.Flight WHERE FlightNo = ?");
                preparedStatement1.setString(1, flightNo);
                resultSet = preparedStatement1.executeQuery();
                if (resultSet.next()) {
                    JOptionPane.showMessageDialog(this, "Flight number already exists.");
                    return;

                }
                
                
             // Get Airports default
            String departAirport;
            String arrivalAirport;

            if (departCity.equals("Dammam")) {
                departAirport = "DMM";
            } else if (departCity.equals("Jeddah")) {
                departAirport = "JED";
            } else {
                departAirport = "RUH"; // Riyadh
            }

            if (arrivalCity.equals("Dammam")) {
                arrivalAirport = "DMM";
            } else if (arrivalCity.equals("Jeddah")) {
                arrivalAirport = "JED";
            } else {
                arrivalAirport = "RUH"; // Riyadh
            }

            // Insert into database
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO SkyWing.Flight VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            preparedStatement.setString(1, flightNo);
            preparedStatement.setString(2, flightType);
            preparedStatement.setTime(3, departTime); 
            preparedStatement.setTime(4, arrivalTime); 
            preparedStatement.setString(5, departCity);
            preparedStatement.setString(6, arrivalCity);
            preparedStatement.setString(7, departAirport);
            preparedStatement.setString(8, arrivalAirport);
            preparedStatement.setString(9, airplaneId);
            preparedStatement.setString(10, gate);
            preparedStatement.setDate(11, new java.sql.Date(flightDate.getTime()));

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Flight added successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add flight!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to add flight!\nError: " + ex.getMessage());
        }
       
            
    }//GEN-LAST:event_AddActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        AboutUs us = new AboutUs();
        us.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        AboutHelp help = new AboutHelp();
        help.setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void iconAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_iconAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_iconAncestorMoved

    private void iconActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iconActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iconActionPerformed

    private void helpComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentMoved

    private void helpComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_helpComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_helpComponentShown

    private void helpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpActionPerformed

    private void helpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_helpKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_helpKeyPressed

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        Home_page logout = new Home_page();
        logout.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_LogoutActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        Admin_Page home = new Admin_Page();
        home.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void flightNoTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_flightNoTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_flightNoTextFieldActionPerformed

    private void arrivalTimeSpinnerAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_arrivalTimeSpinnerAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_arrivalTimeSpinnerAncestorAdded

    private void dateSpinnerAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_dateSpinnerAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_dateSpinnerAncestorAdded

    private void flightTypeComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_flightTypeComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_flightTypeComboBoxActionPerformed

    private void departCityComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_departCityComboBoxActionPerformed

    }//GEN-LAST:event_departCityComboBoxActionPerformed

    private void departTimeSpinnerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_departTimeSpinnerMouseClicked


    }//GEN-LAST:event_departTimeSpinnerMouseClicked

    private void airplaneIdComboBoxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_airplaneIdComboBoxMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_airplaneIdComboBoxMouseClicked

    private void arrivalCityComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_arrivalCityComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_arrivalCityComboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin_addF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin_addF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin_addF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin_addF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin_addF().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JLabel Email;
    private javax.swing.JLabel Email2;
    private javax.swing.JLabel Email3;
    private javax.swing.JLabel Email7;
    private javax.swing.JLabel Email8;
    private javax.swing.JLabel Email9;
    private javax.swing.JLabel Fname;
    private javax.swing.JLabel Fname1;
    private javax.swing.JMenuItem Logout;
    private javax.swing.JLabel Username;
    private javax.swing.JComboBox airplaneIdComboBox;
    private javax.swing.JComboBox<String> arrivalCityComboBox;
    private javax.swing.JSpinner arrivalTimeSpinner;
    private javax.swing.JSpinner dateSpinner;
    private javax.swing.JComboBox<String> departCityComboBox;
    private javax.swing.JSpinner departTimeSpinner;
    private javax.swing.JTextField flightNoTextField;
    private javax.swing.JComboBox<String> flightTypeComboBox;
    private javax.swing.JComboBox<String> gateComboBox;
    private javax.swing.JMenu help;
    private javax.swing.JMenu icon;
    private javax.swing.JLabel id;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JMenu prof;
    // End of variables declaration//GEN-END:variables
}
